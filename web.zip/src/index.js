import React from 'react';
import ReactDOM from 'react-dom';
import Board from './Board';
{/*import App from './App';*/}


ReactDOM.render(
  <React.StrictMode>
    {/*<App />*/}
    <Board/>

  </React.StrictMode>,
  document.getElementById('root')
);
